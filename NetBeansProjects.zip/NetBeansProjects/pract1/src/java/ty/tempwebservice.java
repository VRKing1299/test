package ty; 
import javax.jws.WebService; 
import javax.jws.WebMethod; 
import javax.jws.WebParam; 
/** 
* 
* @author JAY 
*/ 
@WebService(serviceName = "tempwebservice") 
public class tempwebservice { 
/** 
* Web service operation 
*/ 
    @WebMethod(operationName = "convertFtoC") 
    public float convertFtoC(@WebParam(name = "a") float a) { 
        //TODO write your implementation code here: 
        return ((a-32)*5/9); 
    } 
 
    /** 
     * Web service operation 
     */ 
    @WebMethod(operationName = "convertCtoF") 
    public float convertCtoF(@WebParam(name = "b") float b) { 
        //TODO write your implementation code here: 
        return ((b*9/5)+32); 
    } 
} 