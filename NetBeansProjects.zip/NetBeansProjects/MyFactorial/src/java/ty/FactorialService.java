package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web Service to calculate the factorial of a number
 */
@WebService(serviceName = "FactorialService")
public class FactorialService {

    /** 
     * Web service operation to calculate the factorial of a number
     */
    @WebMethod(operationName = "calculateFactorial")
    public long calculateFactorial(@WebParam(name = "number") int number) {
        return factorial(number);  // Call the helper method to calculate the factorial
    }

    // Helper method to calculate the factorial
    private long factorial(int number) {
        if (number == 0 || number == 1) {
            return 1;
        } else {
            return number * factorial(number - 1);  // Recursion
        }
    }
}
