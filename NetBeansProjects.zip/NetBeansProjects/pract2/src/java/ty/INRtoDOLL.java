package ty; 
import javax.jws.WebService; 
import javax.jws.WebMethod; 
import javax.jws.WebParam; 
/** 
* 
* @author JAY 
*/ 
@WebService(serviceName = "INRtoDOLL") 
public class INRtoDOLL { 
/** 
* This is a sample web service operation 
     */ 
    @WebMethod(operationName = "hello") 
    public String hello(@WebParam(name = "name") String txt) { 
        return "Hello " + txt + " !"; 
    } 
 
    /** 
     * Web service operation 
     */ 
    @WebMethod(operationName = "INRtoDOLL_converter") 
    public double INRtoDOLL_converter(@WebParam(name = "INR") double INR) { 
        //TODO write your implementation code here: 
        return (INR/83.11); 
    } 
} 