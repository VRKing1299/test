package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web service for basic calculator operations
 */
@WebService(serviceName = "CalculatorService")
public class CalculatorService {

    @WebMethod(operationName = "add")
    public float add(@WebParam(name = "num1") float num1, @WebParam(name = "num2") float num2) {
        return num1 + num2;
    }

    @WebMethod(operationName = "subtract")
    public float subtract(@WebParam(name = "num1") float num1, @WebParam(name = "num2") float num2) {
        return num1 - num2;
    }
}
