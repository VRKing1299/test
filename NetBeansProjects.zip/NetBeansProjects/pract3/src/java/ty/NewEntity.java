/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ty;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@XmlRootElement
public class NewEntity implements Serializable {

    private String ProductName;

    /**
     * Get the value of ProductName
     *
     * @return the value of ProductName
     */
    public String getProductName() {
        return ProductName;
    }

    /**
     * Set the value of ProductName
     *
     * @param ProductName new value of ProductName
     */
    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }
    
    private int Quantity;

    /**
     * Get the value of Quantity
     *
     * @return the value of Quantity
     */
    public int getQuantity() {
        return Quantity;
    }

    /**
     * Set the value of Quantity
     *
     * @param Quantity new value of Quantity
     */
    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    private String expDate;

    /**
     * Get the value of expDate
     *
     * @return the value of expDate
     */
    public String getExpDate() {
        return expDate;
    }

    /**
     * Set the value of expDate
     *
     * @param expDate new value of expDate
     */
    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }


    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NewEntity)) {
            return false;
        }
        NewEntity other = (NewEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ty.NewEntity[ id=" + id + " ]";
    }
    
}
