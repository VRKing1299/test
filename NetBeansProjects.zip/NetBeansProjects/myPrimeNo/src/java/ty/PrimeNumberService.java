package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web Service to check if a number is prime
 */
@WebService(serviceName = "PrimeNumberService")
public class PrimeNumberService {

    /** 
     * Web service operation to check if a number is prime
     */
    @WebMethod(operationName = "isPrime")
    public boolean isPrime(@WebParam(name = "num") int num) {
        if (num <= 1) {
            return false;  // Numbers less than or equal to 1 are not prime
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;  // If divisible by any number other than 1 and itself, it's not prime
            }
        }
        return true;  // Prime if no divisors found
    }
}
