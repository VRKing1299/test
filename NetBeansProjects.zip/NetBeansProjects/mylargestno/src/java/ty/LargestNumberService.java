package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web Service to find the largest of two numbers
 */
@WebService(serviceName = "LargestNumberService")
public class LargestNumberService {

    /** 
     * Web service operation to find the largest number
     */
    @WebMethod(operationName = "findLargest")
    public float findLargest(@WebParam(name = "a") float a, @WebParam(name = "b") float b) {
        return a > b ? a : b;  // Return the larger of the two numbers
    }
}
