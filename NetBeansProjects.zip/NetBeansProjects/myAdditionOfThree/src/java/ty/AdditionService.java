package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web Service to add three numbers
 */
@WebService(serviceName = "AdditionService")
public class AdditionService {

    /** 
     * Web service operation to add three numbers
     */
    @WebMethod(operationName = "addThreeNumbers")
    public float addThreeNumbers(@WebParam(name = "num1") float num1, 
                                 @WebParam(name = "num2") float num2,
                                 @WebParam(name = "num3") float num3) {
        return num1 + num2 + num3;  // Return the sum of the three numbers
    }
}
