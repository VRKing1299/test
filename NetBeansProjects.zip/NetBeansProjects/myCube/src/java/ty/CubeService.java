package ty;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 * Web Service to calculate the cube of a number
 */
@WebService(serviceName = "CubeService")
public class CubeService {

    /** 
     * Web service operation to calculate the cube of a number
     */
    @WebMethod(operationName = "calculateCube")
    public double calculateCube(@WebParam(name = "num") double num) {
        return Math.pow(num, 3);  // Return the cube of the number (num^3)
    }
}
