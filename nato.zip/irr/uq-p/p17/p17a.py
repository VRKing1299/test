import string

# Function to clean and preprocess the documents
def preprocess(doc):
    # Convert text to lowercase and remove punctuation
    doc = doc.lower()
    doc = doc.translate(str.maketrans('', '', string.punctuation))
    return doc.split()

# Function to build the inverted index
def build_inverted_index(docs):
    inverted_index = {}
    
    # Process each document
    for doc_id, doc in enumerate(docs):
        words = preprocess(doc)
        
        for word in words:
            if word not in inverted_index:
                inverted_index[word] = []
            # Store the document ID for each word occurrence
            if doc_id not in inverted_index[word]:
                inverted_index[word].append(doc_id)
    
    return inverted_index

# Example documents
document1 = "our class meeting starts soon"
document2 = "my class starts at 6."

# List of documents
docs = [document1, document2]

# Build inverted index
inverted_index = build_inverted_index(docs)

# Output the inverted index
print("Inverted Index:")
for word, doc_ids in inverted_index.items():
    print(f"'{word}': {doc_ids}")
