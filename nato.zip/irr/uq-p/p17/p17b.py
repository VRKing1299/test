import spacy

# Load the pre-trained English model from spaCy
nlp = spacy.load("en_core_web_sm")

# Sample document to answer questions from
document = """
India has the second-largest population in the world. It is surrounded by oceans from three sides, which are the Bay of Bengal in the east,
the Arabian Sea in the west, and the Indian Ocean in the south. Tiger is the national animal of India. The peacock is the national bird of India.
Mango is the national fruit of India.
"""

# Define a function to extract named entities from the text
def extract_entities(doc):
    entities = {}
    for ent in doc.ents:
        entities[ent.text] = ent.label_
    return entities

# Define a function to extract noun phrases (which may help answer specific questions)
def extract_noun_phrases(doc):
    noun_phrases = [chunk.text for chunk in doc.noun_chunks]
    return noun_phrases

# Function to answer the question based on the document and extracted information
def answer_question(question, doc):
    doc = nlp(doc)
    
    # Extract entities and noun phrases from the document
    entities = extract_entities(doc)
    noun_phrases = extract_noun_phrases(doc)
    
    # Simple rules-based matching for different types of questions
    question = question.lower()

    # Answer specific questions based on keywords
    if "national animal" in question:
        return "The national animal of India is Tiger."
    elif "national bird" in question:
        return "The national bird of India is the peacock."
    elif "national fruit" in question:
        return "The national fruit of India is Mango."
    elif "largest population" in question:
        return "India has the second-largest population in the world."
    elif "oceans" in question:
        return "India is surrounded by the Bay of Bengal, the Arabian Sea, and the Indian Ocean."
    elif "where" in question:
        if "India" in entities:
            return "India is located in South Asia."
    elif "tiger" in question:
        return "Tiger is the national animal of India."
    else:
        return "Sorry, I don't have an answer for that."

# Example Queries
queries = [
    "What is the national animal of India?",
    "What is the national bird of India?",
    "Which country has the largest population?",
    "Where is India located?",
    "Which ocean surrounds India?"
]

# Run the QA system
for query in queries:
    answer = answer_question(query, document)
    print(f"Question: {query}")
    print(f"Answer: {answer}\n")
