from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score
import numpy as np

# Example data: Actual (ground truth) and predicted labels for a binary classification problem
# 1 represents relevant documents, 0 represents non-relevant documents
y_true = np.array([1, 0, 1, 1, 0, 0, 1, 0, 1, 0])  # Ground truth (relevance)
y_pred = np.array([1, 0, 1, 0, 0, 0, 1, 0, 1, 1])  # Predicted relevance

# Calculate Precision, Recall, F1-Score
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)

# Calculate Average Precision
average_precision = average_precision_score(y_true, y_pred)

# Output the results
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"Average Precision: {average_precision:.4f}")
