import spacy

# Load English NLP model
nlp = spacy.load("en_core_web_sm")

# Sample context
context = """
Alan Turing was a British mathematician and computer scientist.
He was born on June 23, 1912 in London.
He is widely considered to be the father of theoretical computer science and artificial intelligence.
Turing worked at Bletchley Park during World War II, where he helped break the German Enigma code.
"""

# Process context
doc = nlp(context)

# Information extraction: Named Entities
entities = {ent.label_: [] for ent in doc.ents}
for ent in doc.ents:
    entities[ent.label_].append(ent.text)

# Print extracted entities
print("Extracted Information:\n")
for label, items in entities.items():
    print(f"{label}: {set(items)}")

# Sample QA function using keyword and NER match
def answer_question(question):
    question = question.lower()
    if "who" in question and "born" in question:
        return entities.get("PERSON", ["Unknown"])[0] + " was born in " + entities.get("GPE", ["Unknown"])[0] + " on " + entities.get("DATE", ["Unknown"])[0] + "."
    elif "where" in question and "work" in question:
        return "Turing worked at " + entities.get("ORG", ["an unknown place"])[0] + "."
    elif "what" in question and "contribution" in question:
        return "He helped break the German Enigma code during World War II."
    elif "who" in question and "father of" in question:
        return "Alan Turing is considered the father of theoretical computer science and artificial intelligence."
    else:
        return "Sorry, I don't know the answer to that."

# Example Questions
questions = [
    "Who was born in London?",
    "Where did Turing work during World War II?",
    "What was his main contribution?",
    "Who is the father of artificial intelligence?"
]

# Ask the questions
print("\nAnswers:\n")
for q in questions:
    print(f"Q: {q}")
    print(f"A: {answer_question(q)}\n")
