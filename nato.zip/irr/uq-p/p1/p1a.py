# Step 1: Preprocessing
import re
from collections import defaultdict

# Sample documents
documents = {
    "doc1": "The computer science students are appearing for practical examination.",
    "doc2": "computer science practical examination will start tomorrow."
}

# Function to preprocess and tokenize
def preprocess(text):
    text = text.lower()  # Lowercase
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text.split()

# Step 2: Inverted Index Construction
def build_inverted_index(docs):
    inverted_index = defaultdict(set)  # word -> set of doc_ids
    for doc_id, text in docs.items():
        words = preprocess(text)
        for word in words:
            inverted_index[word].add(doc_id)
    return inverted_index

# Step 3: Document Retrieval Function
def retrieve_documents(inverted_index, query_terms):
    query_terms = [term.lower() for term in query_terms]
    result_sets = [inverted_index.get(term, set()) for term in query_terms]
    if not result_sets:
        return set()
    return set.intersection(*result_sets)

# Build the inverted index
inverted_index = build_inverted_index(documents)

# Display the inverted index
print("Inverted Index:\n")
for term, doc_ids in inverted_index.items():
    print(f"{term}: {sorted(doc_ids)}")

# Retrieve documents containing both "computer" and "science"
query = ["computer", "science"]
result_docs = retrieve_documents(inverted_index, query)

# Display the retrieval results
print("\nDocuments containing both 'computer' and 'science':")
if result_docs:
    for doc_id in result_docs:
        print(f"{doc_id}: {documents[doc_id]}")
else:
    print("No documents found containing all query terms.")
