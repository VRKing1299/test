# Corpus of documents
documents = [
    "BSc lectures start at 7.",
    "My lectures are over.",
    "Today is a holiday."
]

# Preprocess the documents by tokenizing and removing punctuation
def preprocess(doc):
    return doc.lower().replace('.', '').split()

# Create an inverted index
def create_inverted_index(docs):
    inverted_index = {}
    
    for doc_id, doc in enumerate(docs):
        words = preprocess(doc)
        for word in words:
            if word not in inverted_index:
                inverted_index[word] = set()
            inverted_index[word].add(doc_id)
    
    return inverted_index

# Process the query "not lectures"
def process_query(query, inverted_index, total_docs):
    query_words = query.split()
    
    # Boolean retrieval (Not operator)
    if "not" in query_words:
        term = query_words[1]
        relevant_docs = set(range(total_docs)) - inverted_index.get(term, set())
    else:
        relevant_docs = inverted_index.get(query_words[0], set())
    
    return relevant_docs

# Create the inverted index for the corpus
inverted_index = create_inverted_index(documents)

# Query processing
query = "not lectures"
relevant_docs = process_query(query, inverted_index, len(documents))

# Output the relevant documents
print(f"Documents matching the query '{query}':")
for doc_id in relevant_docs:
    print(f"Document {doc_id + 1}: {documents[doc_id]}")
