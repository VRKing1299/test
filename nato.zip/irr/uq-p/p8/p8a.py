#same as p5b.py
