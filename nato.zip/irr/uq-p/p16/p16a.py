import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import pandas as pd

# Define the corpus of documents
documents = [
    "Machine learning is the study of computer algorithms that improve through experience.",
    "Deep learning is a subset of machine learning.",
    "Natural language processing is a field of artificial intelligence.",
    "Computer vision is a field of study that enables computers to interpret the visual world.",
    "Reinforcement learning is a machine learning algorithm.",
    "Information retrieval is the process of obtaining information from a collection.",
    "Text mining is the process of deriving high-quality information from text.",
    "Data clustering is the task of dividing a set of objects into groups.",
    "Hierarchical clustering builds a tree of clusters.",
    "K-means clustering is a method of vector quantization."
]

# Step 1: Convert the documents to a numerical format using TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(documents)

# Step 2: Apply K-means clustering (let's choose 3 clusters for example)
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X)

# Step 3: Display the cluster assignments
cluster_labels = kmeans.labels_

# Step 4: Display documents with their cluster labels
doc_cluster = pd.DataFrame({'Document': documents, 'Cluster': cluster_labels})
print(doc_cluster)

# Optional: Display the centroids of the clusters (which are the most important terms in each cluster)
terms = vectorizer.get_feature_names_out()
centroids = kmeans.cluster_centers_

print("\nCentroids (Top terms for each cluster):")
for i in range(3):
    print(f"\nCluster {i + 1}:")
    centroid_terms = [terms[ind] for ind in centroids[i].argsort()[-5:]]
    print(centroid_terms)
