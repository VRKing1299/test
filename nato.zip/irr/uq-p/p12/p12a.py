from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Corpus
corpus = [
    "India has the second-largest population in the world.",
    "It is surrounded by oceans from three sides which are Bay Of Bengal in the east, the Arabian Sea in the west and Indian oceans in the south.",
    "Tiger is the national animal of India.",
    "Peacock is the national bird of India.",
    "Mango is the national fruit of India."
]

# Query
query = "Which is the national bird of India?"

# Step 1: Combine the query with the corpus
documents = corpus + [query]  # Add the query to the corpus

# Step 2: Convert the documents to TF-IDF features
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(documents)

# Step 3: Compute the cosine similarity between the query and the documents
cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])

# Step 4: Get the index of the most similar document
most_similar_doc_index = cosine_similarities.argmax()

# Step 5: Output the most similar document as the answer
answer = corpus[most_similar_doc_index]
print(f"Answer: {answer}")
