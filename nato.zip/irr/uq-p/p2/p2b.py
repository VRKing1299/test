# Given values
TP = 60  # True Positive
FP = 30  # False Positive
FN = 20  # False Negative

# Step 1: Calculate Precision, Recall, and F-score
def calculate_metrics(TP, FP, FN):
    # Precision = TP / (TP + FP)
    precision = TP / (TP + FP)
    
    # Recall = TP / (TP + FN)
    recall = TP / (TP + FN)
    
    # F-score = 2 * (Precision * Recall) / (Precision + Recall)
    f_score = 2 * (precision * recall) / (precision + recall)
    
    return precision, recall, f_score

# Step 2: Get the metrics
precision, recall, f_score = calculate_metrics(TP, FP, FN)

# Step 3: Display the results
print(f"Precision: {precision:.2f}")
print(f"Recall: {recall:.2f}")
print(f"F-score: {f_score:.2f}")
