import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import urljoin, urlparse

# Step 1: Define the crawler class
class WebCrawler:
    def __init__(self, base_url):
        self.base_url = base_url
        self.visited = set()  # Set to store visited URLs
        self.index = {}  # Dictionary to store indexed words

    # Step 2: Fetch the content of a web page
    def fetch_page(self, url):
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                return response.text
            else:
                return None
        except requests.RequestException as e:
            print(f"Error fetching {url}: {e}")
            return None

    # Step 3: Parse the page and extract text
    def parse_page(self, url, content):
        soup = BeautifulSoup(content, 'html.parser')
        # Extract and clean text from the page
        text = soup.get_text()
        # Split the text into words and update the index
        words = re.findall(r'\w+', text.lower())  # Using regex to find words
        return words

    # Step 4: Index the words on the page
    def index_page(self, url, words):
        for word in words:
            if word not in self.index:
                self.index[word] = set()
            self.index[word].add(url)

    # Step 5: Crawl the page and follow links
    def crawl(self, url):
        # If the page has already been visited, don't visit it again
        if url in self.visited:
            return
        
        # Mark the URL as visited
        print(f"Crawling: {url}")
        self.visited.add(url)
        
        # Fetch and parse the page
        content = self.fetch_page(url)
        if content:
            words = self.parse_page(url, content)
            self.index_page(url, words)
        
        # Extract and follow links on the page
        soup = BeautifulSoup(content, 'html.parser')
        links = soup.find_all('a', href=True)
        for link in links:
            href = link['href']
            # Resolve relative URLs
            full_url = urljoin(url, href)
            parsed_url = urlparse(full_url)
            # Only follow links within the same domain
            if parsed_url.netloc == urlparse(self.base_url).netloc and full_url not in self.visited:
                self.crawl(full_url)

    # Step 6: Start the crawling process
    def start_crawling(self):
        self.crawl(self.base_url)

# Step 7: Display the index
def display_index(index):
    print("\nIndexed Words and their URLs:")
    for word, urls in index.items():
        print(f"{word}: {', '.join(urls)}")

# Example usage:
base_url = 'http://example.com'  # Replace with the starting URL
crawler = WebCrawler(base_url)

# Start the crawling process
crawler.start_crawling()

# Display the index after crawling
display_index(crawler.index)
