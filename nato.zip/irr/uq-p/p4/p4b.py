import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re
import time
import random
from urllib.robotparser import RobotFileParser
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By

# Step 1: Define the crawler class
class WebCrawler:
    def __init__(self, base_url):
        self.base_url = base_url
        self.visited = set()  # Set to store visited URLs
        self.index = {}  # Dictionary to store indexed words
        self.robots_txt = None

    # Step 2: Check robots.txt and handle restrictions
    def check_robots_txt(self):
        robots_url = urljoin(self.base_url, "/robots.txt")
        print(f"Checking robots.txt: {robots_url}")
        rp = RobotFileParser()
        try:
            rp.set_url(robots_url)
            rp.read()
            self.robots_txt = rp
        except requests.RequestException as e:
            print(f"Error reading robots.txt: {e}")
            self.robots_txt = None

    # Step 3: Fetch the content of a web page using requests (for static pages)
    def fetch_page(self, url):
        try:
            if self.robots_txt and not self.robots_txt.can_fetch('*', url):
                print(f"Blocked by robots.txt: {url}")
                return None
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                return response.text
            else:
                return None
        except requests.RequestException as e:
            print(f"Error fetching {url}: {e}")
            return None

    # Step 4: Fetch the content using Selenium (for dynamic pages)
    def fetch_dynamic_page(self, url):
        # Initialize Selenium WebDriver (Chrome)
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # Run in headless mode
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
        
        try:
            driver.get(url)
            time.sleep(2)  # Wait for JavaScript to load
            content = driver.page_source
            return content
        except Exception as e:
            print(f"Error fetching dynamic content from {url}: {e}")
            return None
        finally:
            driver.quit()

    # Step 5: Parse the page and extract text
    def parse_page(self, url, content):
        soup = BeautifulSoup(content, 'html.parser')
        # Extract and clean text from the page
        text = soup.get_text()
        # Split the text into words and update the index
        words = re.findall(r'\w+', text.lower())  # Using regex to find words
        return words

    # Step 6: Index the words on the page
    def index_page(self, url, words):
        for word in words:
            if word not in self.index:
                self.index[word] = set()
            self.index[word].add(url)

    # Step 7: Crawl the page and follow links
    def crawl(self, url, use_selenium=False):
        # If the page has already been visited, don't visit it again
        if url in self.visited:
            return
        
        # Mark the URL as visited
        print(f"Crawling: {url}")
        self.visited.add(url)
        
        # Fetch and parse the page
        if use_selenium:
            content = self.fetch_dynamic_page(url)
        else:
            content = self.fetch_page(url)
        
        if content:
            words = self.parse_page(url, content)
            self.index_page(url, words)
        
        # Extract and follow links on the page
        soup = BeautifulSoup(content, 'html.parser')
        links = soup.find_all('a', href=True)
        for link in links:
            href = link['href']
            # Resolve relative URLs
            full_url = urljoin(url, href)
            parsed_url = urlparse(full_url)
            # Only follow links within the same domain
            if parsed_url.netloc == urlparse(self.base_url).netloc and full_url not in self.visited:
                # Introduce a random delay to respect crawling delays
                time.sleep(random.uniform(1, 3))  # Random delay between 1 and 3 seconds
                self.crawl(full_url, use_selenium)

    # Step 8: Start the crawling process
    def start_crawling(self):
        self.check_robots_txt()
        self.crawl(self.base_url)

    # Step 9: Display the index
    def display_index(self):
        print("\nIndexed Words and their URLs:")
        for word, urls in self.index.items():
            print(f"{word}: {', '.join(urls)}")

# Example usage:
base_url = 'http://example.com'  # Replace with the starting URL
crawler = WebCrawler(base_url)

# Start the crawling process
crawler.start_crawling()

# Display the index after crawling
crawler.display_index()
