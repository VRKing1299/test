import nltk
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Ensure NLTK resources are downloaded
nltk.download('punkt')

# Given text data
text = """
Natural language processing (NLP) is a field of computer science,
artificial intelligence,
and computational linguistics concerned with the interactions between
computers and human
(natural) languages. As such, NLP is related to the area of human–
computer interaction.
Many challenges in NLP involve natural language understanding, natural
language generation,
and machine learning.
Text summarization is the process of distilling the most important
information from a source
(text) to produce an abridged version for a particular user or task.
Automatic text summarization methods are greatly needed to address the
ever-growing amount of text data available online to both better help
discover relevant information and to consume the vast amount of text
data available more efficiently.
"""

# Step 1: Split the text into sentences
from nltk.tokenize import sent_tokenize
sentences = sent_tokenize(text)

# Step 2: TF-IDF Vectorization
vectorizer = TfidfVectorizer(stop_words='english')
sentence_vectors = vectorizer.fit_transform(sentences)

# Step 3: Compute sentence scores (similarity with all other sentences)
similarity_matrix = cosine_similarity(sentence_vectors)
sentence_scores = similarity_matrix.sum(axis=1)

# Step 4: Rank and select top N sentences (e.g., 3)
N = 3
top_sentence_indices = sentence_scores.argsort()[-N:][::-1]
top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]

# Step 5: Print the summary
print("Summary:\n")
for sentence in top_sentences:
    print(sentence)




#optional code:
'''
import numpy as np
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Download NLTK resources
nltk.download('punkt')
from nltk.tokenize import sent_tokenize

# Step 1: Define the input text
text = """
Natural language processing (NLP) is a field of computer science, artificial intelligence,
and computational linguistics concerned with the interactions between computers and human
(natural) languages. As such, NLP is related to the area of human–computer interaction.
Many challenges in NLP involve natural language understanding, natural language generation,
and machine learning.
Text summarization is the process of distilling the most important information from a source
(text) to produce an abridged version for a particular user or task.
Automatic text summarization methods are greatly needed to address the ever-growing amount of text data
available online to both better help discover relevant information and to consume the vast amount of text
data available more efficiently.
"""

# Step 2: Sentence tokenization
sentences = sent_tokenize(text)

# Step 3: Preprocess and vectorize sentences using TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(sentences)

# Step 4: Calculate similarity between sentences
similarity_matrix = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Step 5: Rank sentences based on similarity (sum of similarities)
sentence_scores = similarity_matrix.sum(axis=1)

# Step 6: Get top N sentences for the summary
N = 3  # Number of sentences in summary
top_sentence_indices = sentence_scores.argsort()[-N:][::-1]
top_sentence_indices.sort()  # Preserve the order in original text

# Step 7: Generate summary
summary = ' '.join([sentences[i] for i in top_sentence_indices])

# Step 8: Output the summary
print("🔍 Summary:\n")
print(summary)
'''