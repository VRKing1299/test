from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Corpus of documents
documents = [
    "Document about python programming language and data analysis.",
    "Document discussing machine learning algorithms and programming techniques.",
    "Overview of natural language processing and its applications."
]

# Query
query = "python programming"

# Create the TfidfVectorizer to convert the documents and query into numerical form
tfidf_vectorizer = TfidfVectorizer(stop_words='english')

# Fit and transform the corpus (documents) and the query
tfidf_matrix = tfidf_vectorizer.fit_transform(documents)
query_vector = tfidf_vectorizer.transform([query])

# Compute the cosine similarity between the query and each document
cosine_sim = cosine_similarity(query_vector, tfidf_matrix)

# Output the similarity for each document
print(f"Cosine Similarity between the query '{query}' and documents:")
for i, sim in enumerate(cosine_sim[0]):
    print(f"Document {i + 1}: {sim:.4f}")
