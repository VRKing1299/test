#same as p9a.py
