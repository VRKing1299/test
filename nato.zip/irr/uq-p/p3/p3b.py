# Step 1: Define the corpus and query
documents = {
    1: "The cat chased the dog around the garden.",
    2: "She was sitting in the garden last night.",
    3: "I read the book the night before."
}

query = "garden or night"

# Step 2: Preprocess the documents and query (convert to lowercase and split into words)
def preprocess(text):
    return set(text.lower().split())

# Step 3: Build the inverted index
def build_inverted_index(documents):
    inverted_index = {}
    for doc_id, text in documents.items():
        words = preprocess(text)
        for word in words:
            if word not in inverted_index:
                inverted_index[word] = set()
            inverted_index[word].add(doc_id)
    return inverted_index

# Step 4: Process the query using the Boolean retrieval model
def boolean_retrieval(query, inverted_index):
    query_terms = query.lower().split(" or ")  # Query terms are separated by 'or'
    result_docs = set()
    
    for term in query_terms:
        term = term.strip()  # Remove any extra spaces
        if term in inverted_index:
            result_docs.update(inverted_index[term])  # Union of document sets for 'or' query
    
    return result_docs

# Build the inverted index for the corpus
inverted_index = build_inverted_index(documents)

# Step 5: Process the query and retrieve matching documents
result_docs = boolean_retrieval(query, inverted_index)

# Step 6: Display the results
print(f"Query: '{query}'")
print(f"Documents matching the query:")
for doc_id in result_docs:
    print(f"Document {doc_id}: {documents[doc_id]}")
