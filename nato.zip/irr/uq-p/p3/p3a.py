# Function to calculate Levenshtein distance (Edit Distance)
def levenshtein_distance(str1, str2):
    # Create a matrix to store results of subproblems
    len_str1 = len(str1)
    len_str2 = len(str2)
    
    # Create a (len_str1+1) x (len_str2+1) matrix
    dp = [[0] * (len_str2 + 1) for _ in range(len_str1 + 1)]
    
    # Fill the base cases (when one of the strings is empty)
    for i in range(len_str1 + 1):
        dp[i][0] = i  # Deleting all characters from str1
    for j in range(len_str2 + 1):
        dp[0][j] = j  # Inserting all characters into str1 to make it str2
    
    # Fill the rest of the matrix
    for i in range(1, len_str1 + 1):
        for j in range(1, len_str2 + 1):
            # If characters are equal, no operation needed
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                # Consider all possibilities: insert, delete, substitute
                dp[i][j] = min(dp[i - 1][j] + 1,   # Deletion
                               dp[i][j - 1] + 1,   # Insertion
                               dp[i - 1][j - 1] + 1)  # Substitution
    
    return dp[len_str1][len_str2]  # The bottom-right cell contains the result

# Step 1: Calculate edit distance between "nature" and "creature"
str1 = "nature"
str2 = "creature"
edit_distance = levenshtein_distance(str1, str2)

# Step 2: Display the result
print(f"Edit distance between '{str1}' and '{str2}': {edit_distance}")
