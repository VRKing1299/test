# Step 1: Define the corpus
documents = {
    1: "The university exam is scheduled next week.",
    2: "The university of mumbai has declared the result."
}

# Step 2: Preprocess the documents
def preprocess(text):
    return text.lower().replace('.', '').split()

# Step 3: Build the inverted index
inverted_index = {}

for doc_id, content in documents.items():
    terms = preprocess(content)
    for term in terms:
        if term not in inverted_index:
            inverted_index[term] = set()
        inverted_index[term].add(doc_id)

# Step 4: Process Boolean Query
def boolean_and_query(query, index):
    # Assume simple 'and' queries
    query_terms = query.lower().split(" and ")
    if len(query_terms) != 2:
        return set()

    term1_docs = index.get(query_terms[0], set())
    term2_docs = index.get(query_terms[1], set())

    return term1_docs.intersection(term2_docs)

# Step 5: Run the query
query = "university and mumbai"
result_docs = boolean_and_query(query, inverted_index)

# Output the result
print("Documents matching query '{}':".format(query))
for doc_id in result_docs:
    print(f"Document {doc_id}: {documents[doc_id]}")
