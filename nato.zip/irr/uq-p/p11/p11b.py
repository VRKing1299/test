# Import necessary libraries


#dont take this practical


from sklearn.datasets import fetch_20newsgroups
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report

# Step 1: Load the dataset (specific categories of interest)
categories = ['alt.atheism', 'soc.religion.christian', 'comp.graphics', 'sci.med']
newsgroups = fetch_20newsgroups(subset='all', categories=categories, remove=('headers', 'footers', 'quotes'))

# Step 2: Preprocess the data (TF-IDF vectorization)
tfidf_vectorizer = TfidfVectorizer(stop_words='english')
X = tfidf_vectorizer.fit_transform(newsgroups.data)
y = newsgroups.target

# Step 3: Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 4: Train the SVM classifier (Support Vector Machine)
svm_classifier = SVC(kernel='linear')  # Linear kernel for text classification
svm_classifier.fit(X_train, y_train)

# Step 5: Make predictions on the test data
y_pred = svm_classifier.predict(X_test)

# Step 6: Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred, target_names=newsgroups.target_names)

# Output the results
print(f"Accuracy: {accuracy:.4f}")
print("Classification Report:\n", classification_rep)
