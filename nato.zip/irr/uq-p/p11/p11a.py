# Importing required libraries

#dont take this practical

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# Load the 20 Newsgroups dataset (considering all categories for now)
newsgroups = fetch_20newsgroups(subset='all', remove=('headers', 'footers', 'quotes'))

# Let's assume we want to filter for two categories: 'rec.autos' and 'sci.space'
categories = ['rec.autos', 'sci.space']

# Load only documents from the selected categories
newsgroups_filtered = fetch_20newsgroups(subset='all', categories=categories, remove=('headers', 'footers', 'quotes'))

# Get the documents (text data) and their corresponding labels
X = newsgroups_filtered.data  # The text documents
y = newsgroups_filtered.target  # The labels (0 or 1 corresponding to categories)

# Split the data into training and testing sets (70% training, 30% testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Convert text data into TF-IDF vectors
tfidf_vectorizer = TfidfVectorizer(stop_words='english')  # Removes common stopwords
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Initialize the Naïve Bayes classifier (MultinomialNB is typically used for text classification)
nb_classifier = MultinomialNB()

# Train the classifier using the training data
nb_classifier.fit(X_train_tfidf, y_train)

# Predict the labels for the test data
y_pred = nb_classifier.predict(X_test_tfidf)

# Evaluate the classifier's performance
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred, target_names=newsgroups_filtered.target_names)

# Output the results
print(f"Accuracy: {accuracy:.4f}")
print("Classification Report:\n", classification_rep)
