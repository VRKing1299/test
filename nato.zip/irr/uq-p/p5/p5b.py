import numpy as np
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Preprocessing the text (removes unwanted characters and tokenizes sentences)
def preprocess(text):
    text = re.sub(r'\s+', ' ', text)  # Remove extra spaces
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text

# Text summarization function (Extractive Summarization using TF-IDF)
def extractive_summary(text, num_sentences=3):
    sentences = text.split('. ')
    sentences = [sentence.strip() for sentence in sentences]  # Remove extra spaces from sentences

    # Preprocess the sentences
    processed_sentences = [preprocess(sentence) for sentence in sentences]
    
    # Use TfidfVectorizer to compute the TF-IDF matrix for the sentences
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_matrix = tfidf_vectorizer.fit_transform(processed_sentences)

    # Calculate cosine similarity between sentences
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

    # Calculate sentence scores by summing the cosine similarities
    sentence_scores = cosine_sim.sum(axis=1)

    # Create a list of sentence indices and scores
    sentence_scores_list = [(index, score) for index, score in enumerate(sentence_scores)]

    # Sort sentences by score in descending order
    sorted_sentence_scores = sorted(sentence_scores_list, key=lambda x: x[1], reverse=True)

    # Select the top N sentences with the highest scores
    top_sentence_indices = [sorted_sentence_scores[i][0] for i in range(num_sentences)]

    # Sort the top sentences by their original position in the text
    top_sentence_indices.sort()

    # Create the summary by joining the selected sentences
    summary = '. '.join([sentences[i] for i in top_sentence_indices])

    return summary

# Example text to summarize
text = """
Artificial intelligence (AI) is intelligence demonstrated by machines, in contrast to the natural intelligence displayed by humans and animals. 
Leading AI textbooks define the field as the study of "intelligent agents": any device that perceives its environment and takes actions that maximize its chance of successfully achieving its goals.
As machines become increasingly capable, tasks considered to require "intelligence" are often removed from the definition of AI, a phenomenon known as the AI effect.
Machine learning (ML) is a subset of AI and focuses on the idea that systems can learn from data, identify patterns and make decisions with minimal human intervention. 
The ultimate goal of AI is to create systems that can function autonomously and improve themselves over time, just like humans.
"""

# Generate the extractive summary
summary = extractive_summary(text, num_sentences=3)

# Print the summary
print("Original Text:\n", text)
print("\nSummarized Text:\n", summary)
