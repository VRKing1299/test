import numpy as np

# Define the web graph as an adjacency matrix
# Pages: A, B, C, D, E
# A -> B, C, D
# B -> C, E
# C -> A, D

# Initialize the adjacency matrix (1 means a link from page i to page j)
graph = {
    'A': ['B', 'C', 'D'],
    'B': ['C', 'E'],
    'C': ['A', 'D'],
    'D': [],
    'E': []
}

# Pages List
pages = ['A', 'B', 'C', 'D', 'E']

# Damping factor
d = 0.85
n = len(pages)

# Initialize PageRank values equally
pr = {page: 1/n for page in pages}

# Create a function to calculate the PageRank
def calculate_pagerank(graph, d=0.85, tol=1e-6, max_iter=100):
    n = len(graph)
    pr = {page: 1/n for page in graph}  # Initialize PageRank to 1/n for each page
    
    # Build link structure (in-degree count for each page)
    in_links = {page: [] for page in graph}  # To store which pages link to the page
    for page, links in graph.items():
        for link in links:
            in_links[link].append(page)
    
    # Iteratively compute the PageRank values
    for _ in range(max_iter):
        new_pr = {}
        for page in graph:
            # Calculate PageRank for the page
            rank_sum = 0
            for linking_page in in_links[page]:
                rank_sum += pr[linking_page] / len(graph[linking_page])
            
            # Apply the PageRank formula
            new_pr[page] = (1 - d) / n + d * rank_sum
        
        # Check for convergence (if the difference is smaller than tolerance)
        diff = sum(abs(new_pr[page] - pr[page]) for page in graph)
        if diff < tol:
            break
        
        pr = new_pr
    
    return pr

# Run the PageRank calculation
pagerank = calculate_pagerank(graph, d)

# Display the results
for page, rank in pagerank.items():
    print(f"Page {page} has a PageRank of {rank:.6f}")

