import numpy as np

# Define the adjacency matrix for the web graph
# Pages: A, B, C, D
# The matrix represents links: 1 if there is a link, 0 if there is no link

# Adjacency matrix (4x4) where rows represent the source page, and columns represent the destination page
# A -> B, C
# B -> C, D
# C -> A, D
# D -> B
graph = np.array([
    [0, 1, 1, 0],  # A -> B, C
    [0, 0, 1, 1],  # B -> C, D
    [1, 0, 0, 1],  # C -> A, D
    [0, 1, 0, 0]   # D -> B
])

# Number of pages in the graph
n = graph.shape[0]

# Damping factor
d = 0.85

# Initialize the PageRank vector (uniform distribution)
pagerank = np.ones(n) / n

# Iterative computation of PageRank
def compute_pagerank(graph, d, max_iter=100, tol=1.0e-6):
    n = graph.shape[0]
    pagerank = np.ones(n) / n  # Initialize with a uniform distribution
    for i in range(max_iter):
        # Create the new PageRank vector
        new_pagerank = np.zeros_like(pagerank)
        
        # Compute the new PageRank values
        for j in range(n):
            incoming_links = graph[:, j]
            for k in range(n):
                if incoming_links[k] == 1:  # If there is a link from page k to page j
                    new_pagerank[j] += pagerank[k] / np.sum(graph[k, :])  # Distribute the rank

        # Apply the damping factor
        new_pagerank = (1 - d) / n + d * new_pagerank

        # Check for convergence
        if np.linalg.norm(new_pagerank - pagerank, 1) < tol:
            break

        pagerank = new_pagerank

    return pagerank

# Compute PageRank
pagerank_values = compute_pagerank(graph, d)

# Map pagerank values to page names (A, B, C, D)
pages = ['A', 'B', 'C', 'D']
pagerank_dict = dict(zip(pages, pagerank_values))

# Print the PageRank values for each page
print("PageRank values:")
for page, rank in pagerank_dict.items():
    print(f"Page {page}: {rank:.4f}")
