from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Define the corpus (documents)
documents = [
    "The sun is the star at the center of the solar system.",
    "She wore a beautiful dress to the party last night.",
    "The book on the table caught my attention immediately.",
    "The solar system consists of the sun and its planets.",
    "Party time is a great time for fun and enjoyment.",
    "The attention span of humans is quite limited.",
    "The table is placed near the window.",
    "The solar system is fascinating and vast.",
    "I read a book every month."
]

# Initialize the TfidfVectorizer to compute the TF-IDF values
vectorizer = TfidfVectorizer(stop_words='english')

# Fit and transform the documents into a TF-IDF matrix
X = vectorizer.fit_transform(documents)

# Apply K-means clustering (let's assume 3 clusters for simplicity)
num_clusters = 3
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
kmeans.fit(X)

# Get the cluster labels
labels = kmeans.labels_

# Display the clustering results
print("Clustering Results:")
for i, label in enumerate(labels):
    print(f"Document {i + 1}: Cluster {label}")

# Evaluate the clustering performance using silhouette score
silhouette_avg = silhouette_score(X, labels)
print(f"\nSilhouette Score: {silhouette_avg:.4f}")

