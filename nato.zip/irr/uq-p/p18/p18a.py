from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Define the corpus (documents)
documents = [
    "The sun is the star at the center of the solar system.",
    "She wore a beautiful dress to the party last night.",
    "The book on the table caught my attention immediately."
]

# Define the query
query = "solar system"

# Initialize the TfidfVectorizer to compute the TF-IDF values
vectorizer = TfidfVectorizer()

# Fit and transform the documents and the query into a TF-IDF matrix
tfidf_matrix = vectorizer.fit_transform(documents)

# Transform the query into a vector using the same vectorizer (must use the same vocabulary)
query_vector = vectorizer.transform([query])

# Compute cosine similarity between the query and each document
cosine_similarities = cosine_similarity(query_vector, tfidf_matrix)

# Print the cosine similarity for each document
print("Cosine Similarity between the query and documents:")
for idx, similarity in enumerate(cosine_similarities[0]):
    print(f"Document {idx + 1}: {similarity:.4f}")
