#same as p5a.py
