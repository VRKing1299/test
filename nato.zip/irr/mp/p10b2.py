import nltk
import spacy
from transformers import pipeline

# Load spaCy English model
nlp = spacy.load("en_core_web_sm")

# Initialize the Huggingface transformers QA pipeline with PyTorch
qa_pipeline = pipeline("question-answering", model="deepset/roberta-base-squad2")

passage = """
Albert Einstein was born in Ulm, in the Kingdom of Württemberg in the German Empire, on 14 March 1879. His father, Hermann Einstein, was a salesman and engineer, and his mother, Pauline Koch, was a homemaker. Albert Einstein was a theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics (alongside quantum mechanics). His work is also known for its influence on the philosophy of science. He is best known to the general public for his mass–energy equivalence formula E = mc², which has been dubbed "the world's most famous equation."
"""

# Function to extract information using spaCy
def extract_information(text):
    doc = nlp(text)
    # Extract named entities (e.g., persons, locations, organizations)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    return entities

def answer_question(passage, question):
    result = qa_pipeline({
        'context': passage,
        'question': question
    })
    return result['answer']

def main():
    question = input("Ask a question: ")
    print("\nExtracting named entities from the passage:")
    entities = extract_information(passage)
    print(entities)
    
    print("\nAnswering the question using the QA system:")
    answer = answer_question(passage, question)
    print(f"Answer: {answer}")

if __name__ == "__main__":
    main()
