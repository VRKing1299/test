import re
from collections import defaultdict
from spellchecker import SpellChecker

def preprocess(document): 
    document = document.lower()     
    tokens = re.findall(r'\b\w+\b', document)  # Tokenize the document     
    return tokens

def create_inverted_index(docs): 
    inverted_index = defaultdict(set)  # Map terms to document IDs     
    for doc_id, doc in enumerate(docs):         
        for term in doc:             
            inverted_index[term].add(doc_id)  # Add document ID to the set for each term     
    return inverted_index 

def correct_spelling(query, spell): 
    # Tokenize the query and correct each term     
    query_terms = query.split()     
    corrected_query = [spell.correction(term) for term in query_terms]     
    return " ".join(corrected_query)

def retrieve_documents(query, inverted_index, spell): 
    # Correct the spelling in the query     
    corrected_query = correct_spelling(query, spell)     
    print(f"Corrected Query: {corrected_query}")     
    query_terms = preprocess(corrected_query)  # Preprocess the corrected query     
    doc_ids = set()  # Set to store document IDs     
    for term in query_terms: 
        if term in inverted_index: 
            doc_ids.update(inverted_index[term])  # Add relevant document IDs     
    return sorted(doc_ids)   

documents = [ 
    "Artificial intelligence and machine learning are revolutionizing the tech industry.", 
    "The stock market is volatile, but there are opportunities in the tech sector.", 
    "Space exploration is a fascinating field of study with constant advancements.", 
    "Advancements in medical technology are improving healthcare outcomes worldwide." 
] 

processed_documents = [preprocess(doc) for doc in documents] 
inverted_index = create_inverted_index(processed_documents) 

# Initialize the spell checker 
spell = SpellChecker() 
query = "artficial intelligenc and tech"  # Example query with misspellings 
retrieved_docs = retrieve_documents(query, inverted_index, spell) 

# Show retrieved documents 
print(f"\nDocuments relevant to the query '{query}': {retrieved_docs}") 
for doc_id in retrieved_docs:     
    print(f"Document {doc_id}: {documents[doc_id]}")
