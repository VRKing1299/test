import numpy as np
import urllib.request

# ✨ Set a custom browser-like User-Agent to avoid HTTP 403 error
opener = urllib.request.build_opener()
opener.addheaders = [('User-agent', 'Mozilla/5.0')]
urllib.request.install_opener(opener)

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score

# 🌼 Fetch the dataset gracefully
newsgroups = fetch_20newsgroups(subset='all', shuffle=True, random_state=42)

# 🧠 Convert text data into TF-IDF feature vectors
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
X = vectorizer.fit_transform(newsgroups.data)  # Feature matrix
y = newsgroups.target                         # Target labels

# ✂️ Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# ⚔️ Initialize and train the Support Vector Machine (SVM) classifier
svm = SVC(kernel='linear', random_state=42)
svm.fit(X_train, y_train)

# 🧾 Predict on the test set
y_pred = svm.predict(X_test)

# 📊 Evaluate performance
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")

# 💬 Display classification report
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=newsgroups.target_names))
