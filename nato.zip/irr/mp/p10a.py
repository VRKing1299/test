"10a-implement a text summarization algorithm using extractive"
import nltk
import heapq
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
nltk.download('punkt')
nltk.download('stopwords')
def preprocess_text(text):
    # Tokenize the text into sentences
    sentences = sent_tokenize(text)
    return sentences
def compute_tfidf(sentences):
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(sentences)
    return tfidf_matrix
def summarize_text(text, num_sentences=3):
    # Preprocess text (tokenize into sentences)
    sentences = preprocess_text(text)
    tfidf_matrix = compute_tfidf(sentences)

    # Get the importance of each sentence by summing up the TF-IDF scores for each word
    sentence_scores = {}
    for i, sentence in enumerate(sentences):
        sentence_scores[i] = sum(tfidf_matrix[i, j] for j in range(tfidf_matrix.shape[1]))
    ranked_sentences = heapq.nlargest(num_sentences, sentence_scores, key=sentence_scores.get)
# Return the selected sentences as the summary
    summary = [sentences[i] for i in sorted(ranked_sentences)]
    return ' '.join(summary)


# Paraphrased text for summarization
text = """
Albert Einstein was born on March 14, 1879, in the city of Ulm, located in the Kingdom of Württemberg within the German Empire. His father, Hermann Einstein, worked as both an engineer and a salesman, while his mother, Pauline Koch, stayed at home and took care of the household. Albert is renowned for his groundbreaking contributions as a theoretical physicist, particularly for his development of the theory of relativity, which, together with quantum mechanics, is considered one of the fundamental pillars of modern physics. His impact also extended to the field of philosophy of science. Einstein is most famously recognized for the equation E = mc², widely regarded as one of the most iconic formulas in science.
"""

# Summarize the text
summary = summarize_text(text, num_sentences=3)
print("Original Text: \n", text)
print("\nSummarized Text: \n", summary)

