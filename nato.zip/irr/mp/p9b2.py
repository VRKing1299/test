import numpy as np
import xgboost as xgb

# Create synthetic ranking data
X = np.array([
    [0.1, 0.2, 0.3],
    [0.4, 0.5, 0.6],
    [0.7, 0.8, 0.9],
    [0.1, 0.4, 0.3],
    [0.4, 0.9, 0.7],
    [0.3, 0.1, 0.5],
    [0.6, 0.7, 0.2],
    [0.5, 0.8, 0.1]
])

# Rank labels
y = np.array([3, 2, 1, 3, 2, 1, 2, 1])
group = [3, 3, 2]  # Query groups

# Create DMatrix for training
dtrain = xgb.DMatrix(X, label=y)
dtrain.set_group(group)

# XGBoost parameters (without 'n_estimators')
params = {
    'objective': 'rank:pairwise',  
    'eval_metric': 'ndcg',        
    'eta': 0.1,                   
    'max_depth': 5                 
}

# Train the ranking model
num_round = 50
bst = xgb.train(params, dtrain, num_round)

# Test data
X_test = np.array([
    [0.2, 0.3, 0.4],
    [0.6, 0.7, 0.5],
    [0.3, 0.4, 0.6]
])
dtest = xgb.DMatrix(X_test)
predictions = bst.predict(dtest)

print("Predictions (rankings):", predictions)
