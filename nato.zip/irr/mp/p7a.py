import requests
from bs4 import BeautifulSoup
import re
from collections import defaultdict
import time

class WebCrawler:
    def __init__(self):
        self.visited_urls = set()  
        self.inverted_index = defaultdict(set)  
        self.url_count = 0  # Keeps track of the number of crawled pages

    def fetch_page(self, url):
        try:
            response = requests.get(url, timeout=5)  
            response.raise_for_status()  # Raise an error if the status is not 200
            return response.text
        except requests.exceptions.RequestException as e:
            print(f"Error fetching {url}: {e}")
            return None

    def parse_html(self, html):
        soup = BeautifulSoup(html, "html.parser")
        # Extract text from the HTML and clean it
        text = soup.get_text(separator=" ", strip=True)
        return text, soup.find_all('a', href=True)  # Returning text and all links

    def preprocess_text(self, text):
        text = text.lower()  
        tokens = re.findall(r'\b\w+\b', text)  # Tokenize and extract words
        return tokens

    def index_page(self, tokens, page_id):
        for token in tokens:
            self.inverted_index[token].add(page_id)

    # Crawl the web recursively (or up to a certain depth)
    def crawl(self, start_url, depth=2):
        if depth <= 0 or start_url in self.visited_urls:
            return
        
        print(f"Crawling: {start_url}")
        html = self.fetch_page(start_url)
        
        if html is None:
            return
        
        self.visited_urls.add(start_url)
        self.url_count += 1
        tokens, links = self.parse_html(html)
        
        # Index the content of the current page
        self.index_page(self.preprocess_text(" ".join(tokens)), self.url_count)
        
        # Recursively crawl all the linked pages (breadth-first approach)
        for link in links:
            full_url = link['href']
            # Ensure that the URL is absolute
            if not full_url.startswith("http"):
                full_url = start_url + full_url
            
            # Recursively crawl the linked page
            self.crawl(full_url, depth - 1)

# Instantiate the web crawler
crawler = WebCrawler()

# Start crawling from a specific URL (Example: 'https://www.bbc.com')
start_url = 'https://www.bbc.com'

# Crawl the web (limit depth to 2 for demonstration purposes)
crawler.crawl(start_url, depth=2)

# Output the results
print("\nCrawling finished.")
print(f"Total pages crawled: {crawler.url_count}")
print(f"Inverted index: {dict(crawler.inverted_index)}")
