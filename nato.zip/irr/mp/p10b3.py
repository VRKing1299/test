def simulated_qa_system():
    # Simulated passage
    passage = """
    Albert Einstein was born in Ulm, in the Kingdom of Württemberg in the German Empire, on 14 March 1879.
    His father, Hermann Einstein, was a salesman and engineer, and his mother, Pauline Koch, was a homemaker.
    Albert Einstein was a theoretical physicist who developed the theory of relativity, one of the two pillars
    of modern physics (alongside quantum mechanics). His work is also known for its influence on the philosophy
    of science. He is best known to the general public for his mass–energy equivalence formula E = mc²,
    which has been dubbed "the world's most famous equation."
    """

    # Simulated named entity recognition output
    entities = [
        ('Albert Einstein', 'PERSON'),
        ('Ulm', 'GPE'),
        ('the Kingdom of Württemberg', 'GPE'),
        ('the German Empire', 'GPE'),
        ('14 March 1879', 'DATE'),
        ('Hermann Einstein', 'PERSON'),
        ('Pauline Koch', 'PERSON'),
        ('E = mc²', 'LAW')
    ]

    # Display prompts and simulated behavior
    print("Ask a question: When was Einstein born?")
    
    print("\nExtracting named entities from the passage:")
    print(entities)

    print("\nAnswering the question using the QA system:")
    print("Answer: 14 March 1879")

# Run the simulated system
simulated_qa_system()
