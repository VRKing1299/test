"9a-RankBoost Algorithm"
import numpy as np
from collections import defaultdict

class RankBoost:
    def __init__(self, n_estimators=10):
        self.n_estimators = n_estimators  # Number of boosting iterations
        self.alphas = []  # Store alpha values (model weight)
        self.models = []  # Store the weak models (stumps)

    def fit(self, X, y):
        n_samples, n_features = X.shape
        weights = np.ones(n_samples) / n_samples
        
        for i in range(self.n_estimators):
            stump = self._create_stump(X, y, weights)
            predictions = stump.predict(X)
            error = np.sum(weights * (predictions != y)) / np.sum(weights)
            alpha = 0.5 * np.log((1 - error) / (error + 1e-10))
            
            weights = weights * np.exp(-alpha * y * predictions)
            weights /= np.sum(weights)  # Normalize to keep weights sum to 1
            
            self.alphas.append(alpha)
            self.models.append(stump)
            
            # If error is very small, break early
            if error < 1e-5:
                break

    def _create_stump(self, X, y, weights):
        best_stump = None
        best_error = float('inf')
        best_predictions = None

        # Try all features and find the best threshold for each feature
        n_samples, n_features = X.shape
        for feature_idx in range(n_features):
            # Sort the samples by the feature values
            sorted_indices = np.argsort(X[:, feature_idx])
            sorted_X = X[sorted_indices]
            sorted_y = y[sorted_indices]
            sorted_weights = weights[sorted_indices]

            # Try all possible thresholds between consecutive data points
            for i in range(1, n_samples):
                threshold = (sorted_X[i-1, feature_idx] + sorted_X[i, feature_idx]) / 2
                predictions = np.where(X[:, feature_idx] > threshold, 1, -1)
                
                error = np.sum(sorted_weights * (predictions != sorted_y)) / np.sum(sorted_weights)
                if error < best_error:
                    best_error = error
                    best_predictions = predictions
                    best_stump = (feature_idx, threshold)

        class Stump:
            def __init__(self, feature_idx, threshold):
                self.feature_idx = feature_idx
                self.threshold = threshold

            def predict(self, X):
                return np.where(X[:, self.feature_idx] > self.threshold, 1, -1)

        return Stump(*best_stump)

    # Aggregate the predictions of all weak models
    def predict(self, X):
        final_predictions = np.zeros(X.shape[0])
        for alpha, model in zip(self.alphas, self.models):
            final_predictions += alpha * model.predict(X)
        return np.sign(final_predictions)

# Example 
if __name__ == "__main__":
    # Example data: X is feature matrix, y is rank labels
    X = np.array([[1, 2], [2, 1], [3, 3], [4, 4]])
    y = np.array([1, -1, 1, -1])  # Positive/negative ranks for pairwise comparisons
    
    # Train RankBoost model
    model = RankBoost(n_estimators=50)
    model.fit(X, y)

    # Test the model
    test_data = np.array([[2, 2], [3, 1]])
    predictions = model.predict(test_data)
    print("Predictions:", predictions)
