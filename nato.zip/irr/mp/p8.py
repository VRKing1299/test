import numpy as np

def page_rank(graph, num_iterations=100, d=0.85):
   
    n = len(graph)  # Total number of webpages
    pages = list(graph.keys())  # List of webpage names
    rank = {page: 1/n for page in pages}  # Initial rank is equally distributed

    link_matrix = np.zeros((n, n))
    page_index = {page: i for i, page in enumerate(pages)}

    for i, page in enumerate(pages):
        outgoing_links = graph[page]
        if len(outgoing_links) == 0:
            continue  # Skip pages with no outgoing links
        for linked_page in outgoing_links:
            j = page_index[linked_page]
            link_matrix[j][i] = 1 / len(outgoing_links)  # Page i links to page j

    # Iterating the PageRank algorithm
    for _ in range(num_iterations):
        new_rank = {}
        for i, page in enumerate(pages):
            rank_sum = 0
            for j in range(n):
                rank_sum += link_matrix[i][j] * rank[pages[j]]
            new_rank[pages[i]] = (1 - d) / n + d * rank_sum
        
        rank = new_rank

    return rank


graph = {
    "Page1": ["Page2", "Page3"],
    "Page2": ["Page3", "Page4"],
    "Page3": ["Page1"],
    "Page4": ["Page3"]
}

rank = page_rank(graph)
for page, score in rank.items():
    print(f"Page: {page}, Rank: {score:.4f}")
