import numpy as np 
from sklearn.metrics import average_precision_score, precision_score, recall_score, f1_score 
from collections import defaultdict 
import re 

def preprocess(document): 
    document = document.lower()     
    tokens = re.findall(r'\b\w+\b', document)     
    return tokens 

def create_inverted_index(docs): 
    inverted_index = defaultdict(set)     
    for doc_id, doc in enumerate(docs):         
        for term in doc:             
            inverted_index[term].add(doc_id)     
    return inverted_index 

def retrieve_documents(query, inverted_index): 
    query_terms = preprocess(query)  # Preprocess the query     
    doc_ids = set()     
    for term in query_terms:         
        if term in inverted_index: 
            doc_ids.update(inverted_index[term])     
    return sorted(doc_ids) 

documents = [ 
    "Quantum computing is a rapidly developing field in computer science.", 
    "The financial markets are highly volatile and affected by global economic factors.", 
    "The study of biodiversity is crucial for understanding the impact of climate change.", 
    "Advancements in renewable energy technologies are changing the global energy landscape.", 
    "The healthcare industry is undergoing a transformation with the adoption of AI technologies." 
] 

processed_documents = [preprocess(doc) for doc in documents] 
inverted_index = create_inverted_index(processed_documents) 

# Querying the system 
query = "quantm computng and financal market"  # Query with misspellings 
retrieved_docs = retrieve_documents(query, inverted_index) 
relevant_docs = {0, 1} 

# relevance (binary: 1 if relevant, 0 if not) 
y_true = [1 if i in relevant_docs else 0 for i in retrieved_docs] 
# Predicted relevance (binary: 1 for retrieved document, 0 otherwise) 
y_pred = [1] * len(retrieved_docs)   

# Compute Average Precision (AP) 
ap = average_precision_score(y_true, y_pred) 
print(f"Average Precision: {ap:.2f}") 

# Compute Precision, Recall, and F1 Score 
precision = precision_score(y_true, y_pred) 
recall = recall_score(y_true, y_pred) 
f1 = f1_score(y_true, y_pred) 

print(f"Precision: {precision:.2f}") 
print(f"Recall: {recall:.2f}") 
print(f"F1 Score: {f1:.2f}")
