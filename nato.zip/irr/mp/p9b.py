"9b-Training the ranking Model"
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
# Create some synthetic data for ranking (typically you'd have a dataset with features and rank labels)
X = np.array([
    [0.1, 0.2, 0.3],
    [0.4, 0.5, 0.6],
    [0.7, 0.8, 0.9],
    [0.1, 0.4, 0.3],
    [0.4, 0.9, 0.7],
    [0.3, 0.1, 0.5],
    [0.6, 0.7, 0.2],
    [0.5, 0.8, 0.1]
])

# Rank labels (higher numbers indicate better rank)
y = np.array([3, 2, 1, 3, 2, 1, 2, 1])
# For example, items 1-3 are from query 1, items 4-6 are from query 2, etc.
group = [3, 3, 2]
dtrain = xgb.DMatrix(X, label=y)
dtrain.set_group(group)
params = {
    'objective': 'rank:pairwise',  
    'eval_metric': 'ndcg',         # Use NDCG (Normalized Discounted Cumulative Gain) as evaluation metric
     'eta': 0.1,                    # Learning rate
    'max_depth': 5,                 # Maximum depth of trees
    'n_estimators': 100            # Number of boosting rounds (trees)
}

# Train the ranking model using XGBoost
num_round = 50
bst = xgb.train(params, dtrain, num_round)

# Make predictions on new data (using the trained model)
X_test = np.array([
    [0.2, 0.3, 0.4],
    [0.6, 0.7, 0.5],
    [0.3, 0.4, 0.6]
])
dtest = xgb.DMatrix(X_test)
predictions = bst.predict(dtest)
print("Predictions (rankings):", predictions)

