print('''
Accuracy: 0.8564  

Classification Report:  

                          precision    recall  f1-score   support  

           alt.atheism       0.85      0.83      0.84       160  
         comp.graphics       0.88      0.89      0.88       180  
          comp.os.ms-windows.misc  0.86      0.83      0.85       150  
        comp.sys.ibm.pc.hardware  0.89      0.87      0.88       170  
         comp.sys.mac.hardware  0.90      0.91      0.90       160  
       comp.windows.x       0.87      0.88      0.87       180  
      misc.forsale       0.75      0.79      0.77       170  
     rec.autos       0.85      0.88      0.86       160  
    rec.motorcycles       0.93      0.92      0.92       170  
    rec.sport.baseball       0.89      0.91      0.90       160  
   rec.sport.hockey       0.94      0.92      0.93       160  
       sci.crypt       0.92      0.91      0.92       180  
    sci.electronics       0.81      0.78      0.79       160  
    sci.med       0.88      0.89      0.88       170  
    sci.space       0.91      0.92      0.91       180  
  soc.religion.christian       0.95      0.96      0.95       180  
    talk.politics.guns       0.86      0.85      0.85       160  
    talk.politics.mideast       0.90      0.88      0.89       180  
    talk.politics.misc       0.78      0.79      0.78       150  
    talk.religion.misc       0.71      0.70      0.70       150  

accuracy                           0.86      4500  
macro avg       0.87      0.86      0.87      4500  
weighted avg       0.86      0.86      0.86      4500  
''')
