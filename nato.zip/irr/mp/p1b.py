import re
from collections import defaultdict
def preprocess(document):
    document = document.lower()
    tokens = re.findall(r'\b\w+\b', document)  # Tokenize the document
    return tokens
documents = [
    "The quick brown fox jumps over the lazy dog.",
    "The dog barked loudly at the fox.",
    "A fox is a quick and clever animal.",
    "Dogs and foxes are both animals."
]
processed_documents = [preprocess(doc) for doc in documents]
def create_inverted_index(docs):
    inverted_index = defaultdict(set)  
    for doc_id, doc in enumerate(docs):
        for term in doc:
            inverted_index[term].add(doc_id)
    return inverted_index
inverted_index = create_inverted_index(processed_documents)
print("Inverted Index:")
for term, doc_ids in inverted_index.items():
    print(f"{term}: {sorted(doc_ids)}")

# Retrieve documents based on query
def retrieve_documents(query, inverted_index):
    query_terms = preprocess(query)  # Preprocess the query
    doc_ids = set()  # Set to store document IDs
    
    for term in query_terms:
        if term in inverted_index:
            doc_ids.update(inverted_index[term])  # Add relevant document IDs
    
    return sorted(doc_ids)  # Return sorted document IDs

query = "quick fox"
retrieved_docs = retrieve_documents(query, inverted_index)

print(f"\nDocuments relevant to the query '{query}': {retrieved_docs}")
for doc_id in retrieved_docs:
    print(f"Document {doc_id}: {documents[doc_id]}")
