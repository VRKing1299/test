import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import AgglomerativeClustering

#Generate synthetic data
X, _ = make_blobs(n_samples=300, centers=3, cluster_std=0.60, random_state=0)
# Perform hierarchical/agglomerative clustering using scipy
Z = linkage(X, method='ward')  # 'ward' minimizes the variance of merged clusters

# Plot the dendrogram
plt.figure(figsize=(10, 7))
dendrogram(Z)
plt.title("Dendrogram for Hierarchical Clustering")
plt.xlabel("Index of Samples")
plt.ylabel("Euclidean Distance")
plt.show()

# Apply Agglomerative Clustering to form actual clusters
# Let's assume we want to form 3 clusters
agg_clust = AgglomerativeClustering(n_clusters=3, affinity='euclidean', linkage='ward')
y_agg = agg_clust.fit_predict(X)
#Plot the resulting clusters
plt.figure(figsize=(8, 6))
plt.scatter(X[:, 0], X[:, 1], c=y_agg, cmap='viridis', s=50)
plt.title("Clusters formed by Agglomerative Clustering")
plt.show()
