# practical 8
#  Design a PDA to accept WCWR where w is any string and WR is reverse of that string and C is a Special symbol.
#or
# Deterministic Pushdown Automata for L = a^nb^n | n >=0) Python Program

class DPDA:
    def __init__(self, trf, input, state):
        self.head = 0
        self.trf = {}
        self.state = str(state)
        self.input = input
        self.trf = trf
        self.stack = ['Z']
        
    def step(self):
        a = self.input[self.head]
        s = self.stack.pop()
        state, ss = self.trf.get((self.state, a, s))
        if ss != '$':  
            for s in ss[::-1]:
                self.stack.append(s)
        self.state = state
        print('{:20s} [{:10s}] {:5s}'.format(self.input[self.head:],''.join(self.stack), self.state)) 
        self.head += 1

    def run(self):
        print('{:20s} [{:10s}] {:5s}'.format(self.input[self.head:],''.join(self.stack), self.state))
        while self.head < len(self.input):
            self.step()
        s = self.stack.pop() 
        if self.trf.get((self.state, '$', s)):  
            state, ss = self.trf.get((self.state, '$', s)) 
            self.state = state 
            print('{:20s} [{:10s}] {:5s}'.format('$',''.join(self.stack), self.state))  
        
        
DPDA({('q', 'a', 'Z'): ('q', 'XZ'),('q', 'a', 'X'):
    ('q', 'XX'),('q', 'b', 'X'): ('p', '$'),  
    ('p', 'b', 'X'): ('p', '$'),  
    ('p', '$', 'Z'): ('acc', 'Z'),},  
     'aaaaaaaaabbbbbbbbb', 'q').run()


