# practicle 5
# Design a program for accepting decimal number divisible by 2 in python.

def stateq0(n):
    if len(n) == 0:
        print("string accepted")
    else:
        if n[0] == '0':
            stateq0(n[1:])
        elif n[0] == '1':
            stateq1(n[1:])

def stateq1(n):
    if len(n) == 0:
        print("string not accepted")
    else:
        if n[0] == '0':
            stateq0(n[1:])
        elif n[0] == '1':
            stateq1(n[1:])


n = int(input())
n = bin(n).replace("0b", "")
stateq0(n)

# inputs
# 200
# 201
# 202
# 203